
package codeforces;

import java.util.*;
public class P236A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int count=0;
        String s=sc.next();
      char[] a=s.toCharArray();
    
   HashSet<Character> b = new HashSet<Character>();
   
   for(char c:a){
       if(b.add(c)==true){
           count++;
       }
   }
    
        if(count%2==0){
            System.out.println("CHAT WITH HER!");
        }
        else{
            System.out.println("IGNORE HIM!");
        }
    
    }
}


package codeforces;
import java.util.*;
public class ChefAndEid {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
     
    int diff=0;
        int t=sc.nextInt();
        for(int k=1; k<=t; k++){                    
        
            int count=0;
            
            int n=sc.nextInt();
        int[] a=new int[n];                               
        for(int i=0; i<a.length; i++){
            a[i]=sc.nextInt();
         }
 
       Arrays.sort(a);
       
       diff=Math.abs(a[0]-a[1]);
       
       for(int i=0; i<a.length-1; i++){
           
           if(Math.abs(a[i]-a[i+1])<diff){
               diff=Math.abs(a[i]-a[i+1]);
           }
           
       }     
            
        
            System.out.println(diff);
        
        }

        
        }  
    }
    


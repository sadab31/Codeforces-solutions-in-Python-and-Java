

package codeforces;

public class Div641 {
    
}


package codeforces;
import java.util.Scanner;
public class P339A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        char a[]=s.toCharArray();
       
        
        for(int j=0; j<s.length(); j++){
        for(int i=0; i<s.length()-2; i++){
        char m=a[i];
        char n=a[i+2];
        
        if(m>n){
        a[i]=n;
        a[i+2]=m;
          
        }
        
        i++;
        }
        j++;
        }
        
        System.out.println(a);
      
        
    }
}

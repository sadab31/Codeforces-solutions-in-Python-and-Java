package codeforces;
import java.util.Scanner;
public class P266A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
       int n=sc.nextInt();
        String s=sc.next();
        char a[]=s.toCharArray();
        
        int count=0;
         for(int i=0; i<a.length-1; i++){
             if(a[i]==a[i+1]){
                 count++;
             }
         }
         
         System.out.println(count);
        
        
        
    }
}

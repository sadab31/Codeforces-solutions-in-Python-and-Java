
package codeforces;
import java.util.Scanner;
public class P158B {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        int t=sc.nextInt();
        
        int one=0;
        int two=0;
        int three=0;
        int four=0;
        
        for(int i=1; i<=t; i++){
            int a=sc.nextInt();
            
            if(a==1){
                one++;
            }
            else if(a==2){
                two++;
            }
            else if(a==3){
                three++;
            }
            else if(a==4){
                four++;
            }
            
            
        }
        
        
       
     
        int temp2=two;
        if(two%2==0){
            two=two/2;
        }
        else{
            two=(two/2)+1;
        }
        
        if(one<=three){
            one=0;
        }
        else{
            one=one-three;
        
            if(temp2%2!=0){
                if(one<=2){
                    one=0;
                }
                else{
                    one=one-2;
                    if(one<=4){
                        one=1;
                    }
                    else{
                        if(one%4==0){
                            one=one/4;
                        }
                        else{
                            one=(one/4+1);
                        }
                    }
                }
                
                
            }
            else{
                 if(one%4==0){
                            one=one/4;
                        }
                        else{
                            one=(one/4+1);
                        }
                
            }
            
        
        }
        
        
        
        
        
        
        
        
        System.out.println(one+two+three+four);
        
        
        
    }
    
}


package codeforces;
import java.util.*;
public class P96A {
    public static void main(String[] args) {
        
        Scanner sc=new Scanner(System.in);
        
        String s=sc.next();
        
        char []a=s.toCharArray();
 
        int count=1; int temp=a[0];
        
      for(int i=0; i<a.length; i++){
          if(count==7){
              break;
          }
          if(a[i]==temp){
              count++;
          }
          else{
              count=1;
              temp=a[i];
          }
          
      }
    
    
        if(count==7){
            System.out.println("YES");
        }
        else{
            System.out.println("NO");
        }

       
    }
    
}

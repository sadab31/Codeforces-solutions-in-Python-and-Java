
package codeforces;
import java.util.*;
public class P791A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        int b=sc.nextInt();
        int count=0;
       while(a<=b){
            a=3*a;
            b=b*2;
            count++;
            if(a>b){
                break;
            }
        }
        System.out.println(count);
    }
}


package codeforces;
import java.util.Scanner;
public class P71A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int k=sc.nextInt();
        int[] a=new int[n];
        
        for(int i=0; i<a.length; i++){
            a[i]=sc.nextInt();
            }
        
        int count=0;
        for(int i=a.length-1; i>=0; i--){
            if(a[i]>=a[k-1]){
                if(a[i]>0){
                    count++;
                }
            }
            
        }
        System.out.println(count);
        
    }
}


package codeforces;
import java.util.*;
public class ZeroArray {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
      
        int t=sc.nextInt();
        for(int g=1; g<=t ; g++){
        
        
        
        int zeroCount=0;
               int mincount=0;
        
        
        int n=sc.nextInt();
        int q=sc.nextInt();
        
        int[] a=new int[n];
        for(int i=0; i<a.length; i++){
            a[i]=sc.nextInt();
        }
       
        for(int i=1; i<=q; i++){
            
           int d=sc.nextInt();
           if(d==1){
               int e=sc.nextInt();
               int f=sc.nextInt();
               a[e]=f;
               
           } 
           else{
               
              
               
               
               for(int l=0; l<a.length; l++){
               int[] b=a.clone();
               Arrays.sort(b);
               int min=b[0];    
                
               for(int k=0; k<a.length; k++){
                       if(a[k]==0){
                           zeroCount++;
                       }
                       else{
                           a[k]=a[k]-min;
                       }
                       
             }
               if(zeroCount==n){
                   break;
               }
               else{
                   zeroCount=0;
                   mincount++;
               }
               }
               
               
               
               
           
               
               
              System.out.println(mincount);  
              mincount=0;
               
               
               
               
           }
           
           
        }
        
        
        }
    }
}

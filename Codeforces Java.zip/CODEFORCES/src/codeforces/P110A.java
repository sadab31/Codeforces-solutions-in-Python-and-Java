
package codeforces;
import java.util.Scanner;
public class P110A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        long n=sc.nextLong();
        long count=0, last=0;
       
        while(n>0){
            if(n%10==4 || n%10==7){
                count++;
            }
            
            n=n/10;
       
        }
       
       
            while(count>0){
                if(count%10==4 || count%10==7){
                   
                }
                else{
                     last++;
                    break;
                }
                count=count/10;
                if(count==0){
                    count=-1;
                }
            }
        
            
       if(count==0){
           System.out.println("NO");
       }
       else{
           if(last==0){
               System.out.println("YES");
           }
           else{
               System.out.println("NO");
           }
       }
            
            
        
        
        
        
        
        
        
    }
    
}


package codeforces;
import java.util.Scanner;
public class P770A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int k=sc.nextInt();
        int count=0;
      for(int i=1; i<=(n-k)+1; i++){
        for(int j=97; j<=97+k-1; j++){
            
           
                  System.out.print((char)j);
                  count++;
                   if(count==n){
          break;
      }
              
            
            
        }
      
      if(count==n){
          break;
      }
      }
    }
    
}


package codeforces;

import java.util.Scanner;
public class MoneyProlem {
    public static void main(String[] args) {
        
        Scanner sc=new Scanner(System.in);
        
        int n=sc.nextInt();
        int p=sc.nextInt();
        int r=sc.nextInt();
        
        int count=0;
        int total=(n*(n+1))/2;
        int sum=0;
        for(int i=1; count<total;i+=1){
            
            
            if (i%2!=0){
                sum=sum+i;
                count+=1;
            }
            
              
            
        }
        
        
        if (sum%p==r){
            System.out.print(p-sum%p+" ");
            System.out.println(sum%p);
        }
        else{
             System.out.print(sum%p+" ");
            System.out.println(p-sum%p);
        }
        
        
        
    }
}

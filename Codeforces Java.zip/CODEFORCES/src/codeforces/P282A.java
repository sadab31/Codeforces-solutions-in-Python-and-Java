
package codeforces;

import java.util.Scanner;
public class P282A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int x=0;
     int y=sc.nextInt();
    
    

     for(int i=0; i<=y; i++){
     
    String a=sc.nextLine();
 
    if(a.contains("+")){
        x++;
    }
    if(a.contains("-")){
        x--;
    }

     }
        System.out.println(x);
        
        
    }
 
}

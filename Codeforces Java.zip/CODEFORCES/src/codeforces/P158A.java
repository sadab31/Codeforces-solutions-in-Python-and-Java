
package codeforces;
import java.util.Scanner;
public class P158A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        int n=sc.nextInt();
        int k=sc.nextInt();
        int p=0;
        int[]a=new int[n];
        for(int i=0; i<a.length; i++){
            
            a[i]=sc.nextInt();
            if(a[i]<=0){
        p++;
               
        }
            
            
        }
        int l=2;
        if(p==a.length){
            System.out.println(0);
        }
        else{
        
        int count=0;
        for(int i=k; i<a.length; i++){
           if(a[k-1]>0){
            if(a[i]==a[k-1]){
                count++;
            }
           }
           
           else{
               if(a[i-l]>0){
                   count++;
                 l++;  
               }
               
           }
        }
        System.out.println(k+count);
        }
    }
}

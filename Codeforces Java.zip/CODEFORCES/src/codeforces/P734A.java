
package codeforces;

import java.util.Scanner;
public class P734A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        String s=sc.next();
        
        char []a=s.toCharArray();
        int count=0;
        for(char b:a){
            if(b=='A'){
                count++;
            }
            
        }
        
        int count2=n-count;
        if(count>count2){
            System.out.println("Anton");
        }
        else if(count <count2){
            System.out.println("Danik");
        }
        else{
            System.out.println("Friendship");
        }
        
        
    }
}


package codeforces;
import java.util.Scanner;
public class P617A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        int a=sc.nextInt(); 
        int count=0;
        
        for(int i=5; i>=1; i--){
            
            if(a%i==0){
                count=count+a/i;
                break;
            }
            else{
                count=count+a/i;
                a=a%i;
            }
            
            
            
            
        }
        System.out.println(count);
        
        
        
        
    }
    
}

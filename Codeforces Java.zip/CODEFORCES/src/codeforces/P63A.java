
package codeforces;
import java.util.Scanner;
class P63A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        int n=sc.nextInt();
        String [] a=new String[n+1];
        int index=0;
        for(int i=0; i<=n; i++){
        
            String s=sc.nextLine();    
        a[index]=s;
        index++;
        
        }
        System.out.println("TEST");
        for(int i=0; i<a.length; i++){
    System.out.println(a[i]);
}
        
        
        System.out.println("OUTPUT");
        for(int i=1; i<=4; i++){
          for(int j=1; j<a.length; j++){
            if(i==1){
            if(a[j].contains("rat")){
                System.out.println(a[i]);
            }
            }
            else if(i==2){
                    if (a[j].contains("woman") || a[i].contains("child")){
                System.out.println(a[i]);
            }
            }
            else if(i==3){
                    if(a[j].contains("man")==true && a[i].contains("woman")==false){
                System.out.println(a[i]);
            }
            }
            else if(i==4){
                    if(a[j].contains("captain")){
                System.out.println(a[i]);
            }
            }
          }
        }
        
        
        
        
        
        


     
    }
}

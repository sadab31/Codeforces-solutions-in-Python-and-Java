
package codeforces;
import java.util.*;
import java.util.stream.*;
public class P160A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        int n=sc.nextInt();
        int[] a=new int[n];
        
        for(int i=0; i<a.length; i++){
            a[i]=sc.nextInt();
        }
        
        Arrays.sort(a);
        
        int sum=0;
        int count=1;
        int total=IntStream.of(a).sum();
  if(total%2==0){
      total=total/2;
  }
  else{
      total=(total)/2;
  }
  
  
  
  
  for(int i=a.length-1; i>0; i--){
 
     sum=sum+a[i];
     if(sum>total){
         break;
     }
     else{
         count++;
     }
      
  }
  
  
  
  
        
        System.out.println(count);  
        

    }
    
}

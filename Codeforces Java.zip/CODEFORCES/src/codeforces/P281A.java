
package codeforces;
import java.util.Scanner;
public class P281A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        String s=sc.nextLine();
     String k=s.toUpperCase();
        System.out.print(k.charAt(0));
    
        for(int i=1; i<s.length(); i++){
        System.out.print(s.charAt(i));
    }
        
    }
}


package codeforces;
import java.util.Scanner;
public class P116A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        int n=sc.nextInt();
        int a=sc.nextInt();
        int b=sc.nextInt();
        int current=b;
        int max=b;
        
        for(int i=2; i<=n; i++){
            
            a=sc.nextInt();
            b=sc.nextInt();
            
            current=current+b-a;
            if(current>max){
                max=current;
            }
            
        }
        System.out.println(max);
        
    }
    
}

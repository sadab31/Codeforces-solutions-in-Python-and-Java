
package codeforces;
import java.util.Scanner;
public class P1343{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int t=sc.nextInt();
        for(int k=1; k<=t; k++){
        
        
        int n=sc.nextInt();
        
        int[] a=new int[n];
        int odd =n/2; int even =0;
        int sum1=0; int sum2=0; int sumX=0;
        
        for(int i=1; i<=n; i++){
            if(i%2!=0  && odd<a.length-1){
                a[odd]=i;
                sum2=sum2+i;
                odd=odd+1;
                
            }
            else if(i%2==0){
               a[even]=i;
                sum1=sum1+i;
                even=even+1;
            }
            if(even>=n/2){
                break;
            }
        }
       
            
         if(((sum1-sum2)%2)==0){
             System.out.println("NO");
         }
         else{
             System.out.println("YES");
             
             
             for(int j=0; j<a.length-1; j++){
                 System.out.print(a[j]+" ");
                
             }
              System.out.println(sum1-sum2);
         }
            
            
        
         
        
        }
    }
}

package codeforces;
import java.util.Scanner;
public class P1180A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        int n=sc.nextInt();
        int sum=0;
        
        for(int i=n; i>1; i--){
            n=n-1;
            
            sum=sum+n*4;
        }
        System.out.println((sum+1));
        
    }
}

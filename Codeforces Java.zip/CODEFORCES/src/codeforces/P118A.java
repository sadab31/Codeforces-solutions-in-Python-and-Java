
package codeforces;
import java.util.Scanner;
public class P118A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        s=s.toLowerCase();
        char [] a=s.toCharArray();
        for(int i=0; i<a.length; i++){
            
            if(a[i]=='a' || a[i]=='e' || a[i]=='i' || a[i]=='o' || a[i]=='u' || a[i]=='y'){
             
                 }
            else{
                  System.out.print(".");
                System.out.print(a[i]);
            }
            
        }
     
        
    }
}

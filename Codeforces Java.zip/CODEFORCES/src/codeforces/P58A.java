
package codeforces;
import java.util.*;
public class P58A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        
    char []a=s.toCharArray();
        int count=0, lcount=0, ocount=0, hcount=0;
        char temp='h';
        for(int i=0; i<a.length; i++){
            if(a[i]=='h' || a[i]=='e' || a[i]=='l' || a[i]=='o'){
                
                if(a[i]=='h' && hcount==0 ){
                    if(temp=='h'){
                        hcount++;
                        count++;
                        temp=a[i];
                    }
                }
                
                else if(a[i]=='e' && hcount !=0){
                    if(temp=='h'){
                        count++;
                        temp=a[i];
                    }
                }
                
                else if(a[i]=='l'){
                    if((temp=='e' || temp=='l') && lcount<2){
                        lcount++;
                        count++;
                        temp=a[i];
                    }
                }
                
                else if(a[i]=='o' && lcount==2 && temp=='l'){
                    count++;
                    ocount++;
                    break;
                }
            }
            if(ocount!=0){
                break;
            }
        }
         
         
        
       if(count>=5){
           System.out.println("YES");
       }
       else{
           System.out.println("NO");
       }
        
    
          
  
        
        
        
    }
}


package codeforces;
import java.util.Scanner;
public class P41A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        String s=sc.next();
        String b="";
        for(int i=s.length()-1; i>=0; i--){
        b=b+s.charAt(i);
            
        }
        String t=sc.next();
        if(b.equals(t)){
            System.out.println("YES");
        }
        else{
            System.out.println("NO");
        }
        
        
        
    }
}

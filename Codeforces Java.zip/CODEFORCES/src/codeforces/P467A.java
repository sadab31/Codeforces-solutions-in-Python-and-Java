package codeforces;
import java.util.Scanner;
public class P467A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        int n=sc.nextInt();
        int count=0;
        for(int i=1; i<=n; i++){
            
            int a=sc.nextInt();
            int b=sc.nextInt();
            
            if(b>a){
                if(b-a>=2){
                count++;
                }
            }
            
            
        }
        System.out.println(count);
    }
}

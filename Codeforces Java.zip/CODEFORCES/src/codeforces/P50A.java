

package codeforces;
import java.util.Scanner;
public class P50A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int m=sc.nextInt();
        int n=sc.nextInt();
        
        
        if(n%2==0){
            System.out.println((n/2)*m);    
        }
        
        
        else{
        n=n-1;
        n=(n/2)*m;
           
        if(m%2==0){
                System.out.println((m/2)+n);    
            }
        else{
            m=m-1;
            m=m/2;
            System.out.println(m+n);
        }
            
        }
        
    }
}

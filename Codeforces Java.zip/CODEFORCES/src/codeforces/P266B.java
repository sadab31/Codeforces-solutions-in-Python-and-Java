
package codeforces;
import java.util.Scanner;
public class P266B {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int t=sc.nextInt();
        
        
        
        String s=sc.next();
        char[] a=s.toCharArray();
        
        for(int k=1; k<=t; k++){
        for(int i=0; i<a.length-1; i++){
            
            if(a[i]=='B'){
                if(a[i+1]=='G'){
                    a[i]='G';
                    a[i+1]='B';
                    i++;
                }
            }
        }
        }
        
        for(char i:a){
            System.out.print(i);
        }
        
        
    }
    
}

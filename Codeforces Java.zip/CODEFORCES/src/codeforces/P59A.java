
package codeforces;
import java.util.Scanner;
public class P59A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
       
        String s=sc.next();
        char []a=s.toCharArray();
        
        int upper=0;
                int lower=0;
        
        for(char n:a){
            
            int x=(int) n;
            if(x>=65 && x<91){
                upper++;
            }
            else{
                lower++;
            }
        }
        
        if(upper>lower){
            s=s.toUpperCase();
        }    
        else{
            s=s.toLowerCase();
        }
        System.out.println(upper);
        System.out.println(lower);
        System.out.println(s);
        
        
    }
}

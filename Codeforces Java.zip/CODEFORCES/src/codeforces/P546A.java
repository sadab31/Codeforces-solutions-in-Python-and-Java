
package codeforces;
import java.util.Scanner;
public class P546A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        int k=sc.nextInt();
        int n=sc.nextInt();
        int w=sc.nextInt();
        long sum=0;
        
        for(int i=1; i<=w; i++){
            
            sum=sum+i*k;
            
        }
      sum=sum-n;
      if(sum<=0){
          System.out.println(0);
      }
      else{
        System.out.println(sum);
      }
    }
    
}


package codeforces;
import java.util.*;
public class P263A {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        int pos1=0;
        int pos2=0;
        int m;
        for(int i=1; i<=5; i++){
            for(int k=1; k<=5; k++){
                m=sc.nextInt();
                if(m!=0){
                    pos1=i;
                    pos2=k;
                }
                
            }
        }
      pos1=Math.abs(3-pos1);
      pos2=Math.abs(3-pos2);
        System.out.println((pos1+pos2));
    }
    
}


package codeforces;


import java.util.*;  

public class P43A {
  public static void main(String[] args) {
      Scanner sc=new Scanner(System.in);
      int n=sc.nextInt();
  
      String [] a=new String[n];
      
      for(int i=0; i<a.length; i++){
          a[i]=sc.next();
      }
  Arrays.sort(a);
     
  
     int count=1;
     
     for(int i=1; i<a.length; i++){
        if(a[i].equals(a[0])){
            count++;
        }
        else{
            break;
        }
         
     }
 
     n=n/2;
     if(count>n){
         System.out.println(a[0]);
     }
     else{
         System.out.println(a[a.length-1]);
     }
  }
}
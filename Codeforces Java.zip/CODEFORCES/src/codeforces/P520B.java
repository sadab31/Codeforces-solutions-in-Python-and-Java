
package codeforces;

import java.util.Scanner;
public class P520B {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        int n=sc.nextInt();
        int m=sc.nextInt();
        int count=0;
        if(n>=m){
            System.out.println(n-m);
        }
  
        else{
            
            while(m>n){
                
                if(m%2==0){
                    m=m/2;
                    count++;
                }
                else{
                    m++; count++;
                }
                
            }
            
            System.out.println((n-m)+count);
            
            
        }
        
        
    }
}
t=int(input())
i=1
while i<=t:
    a,b=map(int,input().split())
    print("Case",str(i)+":",a+b)
    i+=1
def prime(a):
    if a == 1:
        return False
    else:

        count = 0

        i = 2
        while i < (a):
            if a % i == 0:
                count += 1
                break
            else:
                i += 1
        if count == 0:
            return True
        else:
            return
t=int(input())
for i in range(t):
    b=int(input())
    if prime(b):
        print("yes")
    else:
        print("no")
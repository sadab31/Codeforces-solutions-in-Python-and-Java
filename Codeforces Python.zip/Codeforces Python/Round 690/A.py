t=int(input())
for i in range(t):
    n = int(input())
    a = list(map(int, input().split()))
    b = a.copy()

    left = 0
    right = n - 1
    i = 0
    while i < n:
        if i < n:
            b[i] = a[left]
            i += 1
            left += 1
        if i < n:
            b[i] = a[right]
            i += 1

            right -= 1

    for i in b:
        print(i,end=" ")
    print()
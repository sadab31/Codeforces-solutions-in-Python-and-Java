t=int(input())
for i in range(t):
    n = int(input())
    s = input()
    i = 0
    s1 = ""
    s2 = ""
    count = 0
    while i < 3:

        if s[i] == "2" and s[i + 1] == "0" and i == 0:

            if s[i + 2] == "2" and s[i + 3] == "0":
                print("YES")
                count += 1
                break
            if s[n - 1] == "0" and s[n - 2] == "2":
                print("YES")
                count += 1
                break
        if i == 0 and s[i] == "2":
            if s[n - 1] == "0" and s[n - 2] == "2" and s[n - 3] == "0":
                print("YES")
                count += 1
                break

        i += 1
    if count == 0:
        print("NO")
k=int(input())
n=int(input())
w=int(input())

sum=0

for i in range(1,w+1):
    sum=sum+(i*k)

print(sum-n)

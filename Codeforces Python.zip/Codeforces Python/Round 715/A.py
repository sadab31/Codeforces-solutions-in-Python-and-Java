t=int(input())
for j in range(t):
    n = int(input())
    a = list(map(int, input().split()))
    even = []
    odd = []


    for i in a:
        if i % 2 == 0:
            even.append(i)
        else:
            odd.append(i)

    main = odd+even

    print(main)
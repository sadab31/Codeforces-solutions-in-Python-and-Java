t=int(input())
for i in range(t):
    n, k = map(int, input().split())

    s = ""
    for i in range(k):
        s += "a"
    temp = ["c", "b", "a"]
    count=0
    while len(s) <= n:
        for i in temp:
            if len(s) >= n:
                count=1
                break
            else:
                s += i
        if count==1:
            break

    print(s)

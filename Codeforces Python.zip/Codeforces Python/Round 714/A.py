t=int(input())
for i in range(t):
    n, k = map(int, input().split())
    splt = n // 2
    flag = False
    if n % 2 == 0:
        if k >= splt:
            print(-1)
            flag = True
    else:
        if k > splt:
            print(-1)
            flag = True

    if flag != True:

        main = list(range(1, n + 1))
        new = []
        left = main[:n - k]
        right = main[n - k:]

        i = 0
        while i < len(left) and i < len(right):
            new.append(left[i])
            new.append(right[i])
            i += 1

        while i < len(left):
            new.append(left[i])
            i += 1
        k = ""
        for i in new:
            k += str(i) + " "
        k = k[:-1]
        print(k)
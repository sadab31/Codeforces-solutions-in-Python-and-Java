t=int(input())
for i in range(t):
    l = list(map(int, input().split()))
    l.sort()
    a = l[0]
    b = l[1]
    c = l[2]

    steps = 0
    if a > 1:
        steps += a - 1
        a=1
    a -= steps // 7
    b -= steps // 7
    c -= steps // 7
    if b > 1:
        steps += b - 1
        b=1
    a -= steps // 7
    b -= steps // 7
    c -= steps // 7
    if c > 1:
        steps += c - 1
        c=1
    a -= steps // 7
    b -= steps // 7
    c -= steps // 7

    if (steps + 1) % 7 == 0 and a == 1 and b == 1 and c == 1:
        print("YES")
    else:
        print("NO")
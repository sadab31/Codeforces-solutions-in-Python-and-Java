t=int(input())
for i in range(t):
    n,k=map(int,input().split())
    x=[]
    y=[]
    for i in range(n):
        a,b=map(int,input().split())
        x.append(a)
        y.append(b)

    count=0



    xx=x[0]
    yy=y[0]

    for m in x:
        if abs(m-xx)>k:
            count+=1
    for n in y:
        if abs(n-yy)>k:
            count+=1
    if count>0:
        print(-1)

    else:
        print(1)

s="trygub"


t=int(input())
for i in range(t):
    n = int(input())
    p = input()
    count = 0
    i = 0
    j = 0
    while i < n:
        if j >= len(s):
            break
        if p[i] == s[j]:

            count += 1
            if p[i] == "b":
                break
            j += 1
        i += 1

    temp = p[i:]
    p = temp + p[:i]
    print(p)
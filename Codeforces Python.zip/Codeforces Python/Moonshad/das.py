
class Movie:
    total_movie=0
    earning=0
    def __init__(self,name=None):
        self.dname=name
        self.number = 0
        self.genre = []
        self.movies = []


    def add_movie(self,name,genre,crime):

        self.genre.append(genre)
        self.movies.append(name)
        self.cost=crime

    def set_director_name(self,name):

        self.dname=name
    def print_details(self):

        print("Director Name:",self.dname)
        print("Number of movies:",len(set(self.movies)))



        first=self.genre[0]
        i=1
        count=1
        while i<len(self.genre):
            if self.genre[i]==first:
                count+=1

            i+=1

        s=self.movies[0]+", "
        i=1
        while i<count:
            if self.movies[i]!=self.movies[i-1]:
                s+=self.movies[i]+", "
            i+=1
        print(self.genre[0]+" : "+s[:-2])
        s=""
        i=count
        while i<len(self.genre):
            print(self.genre[i]+" : "+self.movies[i])
            i+=1
















print('Total movies in the database:', Movie.total_movie)
print('Total Earning so far:', Movie.earning, 'M')
print("=================================")
a1 = Movie()
a1.add_movie('Raising Arizona', 'Comedy-Crime', 29.2)
print("=================================")
a1.set_director_name('Joel Coen')
a1.add_movie('Raising Arizona', 'Comedy-Crime', 29.2)
a1.print_details()

print("=================================")
a1.add_movie('The Big Lebowski', 'Comedy-Crime', 46.7)
a1.add_movie('True Grit', 'Western-Drama', 252.2)
a1.print_details()

print("=================================")
a2 = Movie('Marc Forster')
a2.add_movie('Machine Gun Preacher', 'Action', 3.3)
a2.add_movie('Quantum of Solace', 'Action', 589.6)
a2.print_details()

print("=================================")
print('Total movies in the database:', Movie.total_movie)
print('Total Earning so far:', Movie.earning, 'M')

t=int(input())
for i in range(t):
    n = int(input())
    if n % 2 == 0:
        while n > 0:
            print(n, end=" ")
            n -= 1
        print("")
    else:

        half = n // 2 + 1


        while n > 0:
            if n == half:
                print(n - 1, end=" ")
                print(n, end=" ")
                n -= 2
            else:
                print(n, end=" ")
                n -= 1
        print("")
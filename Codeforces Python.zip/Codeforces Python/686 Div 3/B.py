t=int(input())
for i in range(t):
    n = int(input())
    num = list(map(int, input().split()))
    unique=list(set(num))
    unique.sort()
    print(unique)
    count=0
    for i in unique:
        if num.count(i)>1:
            count+=1
        else:
            print(num.index(i)+1)
            break
    if count==len(unique):
        print(-1)

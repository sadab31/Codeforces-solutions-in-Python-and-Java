t=int(input())
for i in range(t):
    n = int(input())
    heros = list(map(int, input().split()))
    count = 0
    for i in heros:
        for j in heros:
            if i > j:
                count += 1
                break
    print(count)
t=int(input())
for i in range(t):
    n, k = map(int, input().split())
    a = n
    b = 1
    for i in range(k - 1):
        if a == 1:
            a = n
        else:
            a -= 1
        if b == n:
            if a == 1:
                b = 2
            else:
                b = 1
        else:
            if b + 1 == a:
                b += 2
            else:
                b += 1

    print(b)
def f1(x):
    x=str(x)
    x=x[::-1]
    if x[0]!=0:
        return int(x)
    else:
        i=0
        while i<len(x):
            if x[i]!=0:
                break
            else:
                i+=1
        return int(x[i:])


t=int(input())
for i in range(t):
    n=int(input())
    count=1
    l=[]
    if n>=10:
        j=1
        while j<=n:
            if j%10==0:
                temp1=f1(j)
                temp2=f1(temp1)
                l.append(j/temp2)
            j+=1
    s=set(l)
    print(count+len(s))



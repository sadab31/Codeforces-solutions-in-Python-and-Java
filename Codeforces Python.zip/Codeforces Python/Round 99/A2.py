t=int(input())
for i in range(t):
    n=int(input())
    a=str(n)
    print(len(a))
t=int(input())
for i in range(t):
    s = input()
    k = list(s)
    if k[0]==")":
        print("NO")
        break
    else:
        k.sort()
        length = len(s)
        if length % 2 != 0:
            print("NO")
        else:
            if k[length // 2] == ")" and k[length // 2 - 1] == "(":
                print("YES")
            elif k.count("?") % 2 == 0:
                print("YES")
            else:
                print("NO")
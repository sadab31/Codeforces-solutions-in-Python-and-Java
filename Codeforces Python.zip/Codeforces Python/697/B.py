t=int(input())
for i in range(t):
    n = int(input())
    times = n // 2020

    last = n % 10

    if last > times:
        print("NO")
    else:
        if (2020 * (times - last)) + (2021 * last) == n:
            print("YES")
        else:
            print("NO")

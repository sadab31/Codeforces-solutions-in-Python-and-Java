import math
t=int(input())
for i in range(t):
    n = int(input())
    if n == 1:
        print("NO")
    elif n % 2 != 0:
        print("YES")
    else:
        i = 3
        flag = False
        while i <= math.floor(math.sqrt(n)):
            if n % i == 0:
                print("YES")
                flag = True
                break
            i += 2
        if flag == False:
            print("NO")


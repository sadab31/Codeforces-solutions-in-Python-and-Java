t=int(input())
for i in range(t):
    n = int(input())
    a = list(map(int, input().split()))
    temp = list(range(0, n))
    flag = True
    i = 0
    while i < len(a):

        if a[i] >= temp[i]:
            if i == len(a) - 1:
                break
            diff = a[i] - temp[i]
            a[i] = temp[i]
            a[i + 1] += diff
        else:
            flag = False

        i += 1

    if flag == True:
        print("YES")
    else:
        print("NO")
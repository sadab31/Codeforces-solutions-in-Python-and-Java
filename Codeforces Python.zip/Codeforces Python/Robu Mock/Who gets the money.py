n, p, r = map(int, input().split())

total = (n * (n + 1)) / 2

sum = int(total * total)

if sum % p == r:
    print(p - sum % p, sum % p)
else:
    print(sum % p, p - sum % p)

import math
from math import comb
t=int(input())
for i in range(t):
    n, x = map(int, input().split())

    least = math.ceil((x / 100) * n)

    sum = 0
    i = least
    while i <= n:
        sum += comb(n, i) * pow(.5, n)
        i += 1
    print("{:.2f}".format(sum))
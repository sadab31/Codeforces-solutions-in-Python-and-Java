t=int(input())
for k in range(t):
    n = int(input())
    i = 1
    count = 0
    while i <= 10:
        j = 1
        while j <= 10:
            if i * j == n:
                count += 1
                break

            j += 1
        i += 1
    if count == 0:
        print("No")
    else:
        print("Yes")

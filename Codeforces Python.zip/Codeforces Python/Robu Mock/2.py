n=int(input())
a=[]
b=[]
for i in range(n):
    t=int(input())
    a.append(t)

i=0
while i<n:
    count = 0
    j = i
    b=[]
    while j < n-1 :


        diff = abs(a[j] - a[j + 1])


        if diff >= 2:
            b.append(a[j + 1])
            count += 1

        else:
            break



        j += 1
    if len(b) == 0:
        print(count)
    else:
        print(count + 1)





    i+=1




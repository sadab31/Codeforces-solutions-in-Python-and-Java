while True:
    s=input()
    if s=="DONE":
        break
    s=s.lower()
    s=s.replace(" ","")
    s=s.replace(",","")
    s=s.replace("!","")
    s=s.replace(".","")
    s=s.replace("?","")

    p=s[::-1]

    if s==p:
        print("You won’t be eaten!")
    else:
        print("Uh oh..")
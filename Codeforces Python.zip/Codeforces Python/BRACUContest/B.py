n = int(input())
a = list(map(int, input().split()))
chest = 0
bicep = 0
back = 0
i = 0
j = 1
k = 2
length = len(a)
cond = 0
while True:  # and j<len(a) and k<len(a)

    if length<3:
        if length>1:
            chest=a[0]
            bicep=a[1]
            break
        else:
            chest=a[0]
            break
    else:
        chest = chest + a[i]
        bicep = bicep + a[j]
        back = back + a[k]

        i += 3
        j += 3
        k += 3
        if i >= length:
            break
        if i >= length:
            i = 0
            a[0] = 0
        if j >= length:
            j = 1
            a[j] = 0

        if k >= length:
            k = 2
            a[k] = 0
if chest>bicep and chest>back:
    print("chest")
elif bicep>chest and bicep>back:
    print("biceps")
elif back > chest and back >bicep:
    print("back")
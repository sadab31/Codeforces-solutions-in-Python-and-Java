s=list(map(int,input().split()))
if max((3*s[0]/10,  s[0]-(s[0]/250*s[2]))) >  max(3*s[1]/10,  s[1]-(s[1]/250*s[3])):
    print("Misha")
elif max((3*s[0]/10,  s[0]-(s[0]/250*s[2]))) <  max(3*s[1]/10,  s[1]-(s[1]/250*s[3])):
    print("Vasya")
else:
    print("Tie")
m=input()
m=m.split(" ")
a=m[0]
b=m[1]

print(max(a+a-1,b+b-1,a+b))
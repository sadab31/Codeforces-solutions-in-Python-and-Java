s=input()
print(s)

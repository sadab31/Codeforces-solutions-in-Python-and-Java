n=int(input())
list = list(map(int, input().split()))
orange=0
for i in list:
    orange=orange+(i/100)
print((orange/n)*100)
t=int(input())
i=1
while i<=t:
    a,b=map(int,input().split())
    sum=a+b
    print("Case",str(i)+":",sum)
    i+=1

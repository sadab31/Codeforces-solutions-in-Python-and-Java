t=int(input())
for i in range(t):
    n=int(input())
    l=list(map(int,input().split()))
    m=l.copy()
    m.sort()
    if m[0]==m[1]:
        print(l.index(m[-1])+1)
    else:
        print(l.index(m[0]) + 1)


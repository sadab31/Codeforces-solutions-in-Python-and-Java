t=int(input())
for i in range(t):
    n=int(input())
    main=[]
    for j in range(n):
        a=input()
        main.append(a)
    index = []
    rowind = 0
    while rowind < len(main):
        rows = main[rowind]

        i=0
        while i<len(rows):
            if rows[i]=="*":
                index.append((rowind,i))
            i+=1


        rowind += 1

    row=[]
    col=[]
    for i in index:
        row.append(i[0])
        col.append(i[1])

    i=0
    while i<len(main):
        if i in row:
            a=list(main[i])
            fst=col[0]
            scd=col[1]
            a[fst]="*"
            a[scd]="*"
            k=""
            k=k.join(a)
            print(k)
        else:
            print(main[i])
        i+=1




    #
    # print(main)
    # print(index)
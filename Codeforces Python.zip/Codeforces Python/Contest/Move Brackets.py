l=int(input())
s=input()

if s[0]=="(" and s[l-1]==")":
    print(0)
else:
    if s[0]==")":
        count=1
        i=l-1
        while i>=0:
            if s[i]=="(":

                break
            count+=1
            i-=1
        print(count)
    elif s[l-1]=="(":
        count=1
        i=0
        while i <=l-1:
            if s[i]==5:
                pass



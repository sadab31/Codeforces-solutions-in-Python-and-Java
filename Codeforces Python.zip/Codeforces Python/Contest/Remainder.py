t=int(input())
for i in range(t):
    list1 = list(map(int, input().split()))
    while list1[2] >= 0:
        if list1[2] % list1[0] == list1[1]:
            break
        list1[2] -= 1
    print(list1[2])

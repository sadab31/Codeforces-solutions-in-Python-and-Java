s,m=map(int,input().split())

numbers=[1]*s

i=-1
while i>=-len(numbers):
    if sum(numbers)==m:
        break
    else:
        pass
    i-=1



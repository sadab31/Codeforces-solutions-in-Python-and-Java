s=input()
if s=="{}":
    print(0)
else:
    s = s[1:-1]

    s = s.split(", ")

    p = []

    for i in s:
        if i not in p:
            p.append(i)
    print(len(p))
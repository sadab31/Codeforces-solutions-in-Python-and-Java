a=input()
b=input()
length=len(a)
new=""
for i in range(length):
    if a[i]==b[i]:
        new=new+"0"
    else:
        new=new+"1"
print(new)
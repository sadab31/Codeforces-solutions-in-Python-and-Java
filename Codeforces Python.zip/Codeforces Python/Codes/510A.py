n,m =map(int,input().split())


i = 1
while i <= n:

    j = 1
    while j <= m:
        if i%2==0:

            a=i//2

            if a%2!=0 and j==m:
                print("#",end="")
            elif a%2==0 and j==1:
                print("#",end="")

            else:

                print(".",end="")
        else:
            print("#", end="")

        j += 1
    print("")

    i += 1

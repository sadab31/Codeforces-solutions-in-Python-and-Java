t=int(input())
s=input()
if len(s)<26:
    print("NO")
else:
    a="a b c d e f g h i j k l m n o p q r s t u v w x y z"
    s=s.lower()
    list1=a.split(" ")
    for i in s:
        if i in list1:
            list1.remove(i)
    if len(list1)==0:
        print("YES")
    else:
        print("NO")

t=int(input())
for i in range(t):
    n = int(input())
    k = 2
    while True:
        a = n / ((2 ** k) - 1)
        if a.is_integer():
            print(int(a))
            break
        k += 1
m,s=map(int,input().split())
temp=m
m=s
s=temp
numbers=[9]*s
difference=9*s-m
low=""
high=""
i=0

if s==0 or m==0:
    if s==1:
        print(0,0)
    else:
        print(-1,-1)
elif 9*s<m:
    print(-1,-1)
else:
    while i < len(numbers):
        if difference >= 9:
            numbers[i] = 0
            difference -= 9
            if difference == 0:
                break
        else:
            numbers[i] = 9 - difference
            break
        i += 1



    i = 0
    while i <len(numbers):
        low += str(numbers[i])
        i += 1

    i=-1
    while i>=-len(numbers):
        high+=str(numbers[i])
        i-=1

    if numbers[0]==0:
        j = 0
        while low[j] == "0":
            j += 1
        numbers[0] = 1
        numbers[j] -= 1
        numbers = list(map(str, numbers))
        low = "".join(numbers)


    print(low,high)




s=input()

count=0
for i in range(1,len(s)):
    a=ord(s[i])
    if a<65 or a>90:
        count+=1
if count==0:
    b=s.capitalize()
    if s[0]==b[0]:
        print(s.lower())
    else:
        print(b)

else:
    print(s)





n=int(input())
list=list(map(int,input().split()))
even=0

for i in range(3):
    if list[i]%2==0:
        even+=1
if even<2:
    even=0
else:
    even=1
temp=0
for i in range(len(list)):
    if even==0:
        if list[i]%2==0:
            temp=i
            break
    elif even==1:
        if list[i]%2!=0:
            temp=i
            break




print(temp+1)

a=int(input())
b=list(map(int,input().split()))

police=0
crime=0

for i in b:
    if i!=-1:
        police+=i
    else:
        if police<=0:
            crime+=1
        else:
            police-=1
print(crime)



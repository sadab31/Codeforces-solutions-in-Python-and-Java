n=int(input())
list=list(map(int,input().split()))
high=0
low=0
max=list[0]
min=list[0]
i=0

while i<n:
    if list[i]>max:

        max=list[i]
        high=i
    if list[i]<=min:
        min=list[i]
        low=i
    i+=1
print(high,low)
if high>low:

    low=low+1
    low=n-low-1
    print(high+low)
elif high<low:
    low=n-low-1
    print(high+low)
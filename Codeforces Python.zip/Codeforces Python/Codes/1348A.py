t=int(input())
for i in range(t):
    n=int(input())
    side=n//2
    main=[]
    j=1
    while j<=n:
        main.append(2**j)
        j+=1
    left=[]
    right=[]
    left.append(main[-1])
    j=0
    while j<side-1:
        left.append(main[j])
        j+=1
    j=side-1
    while j<len(main)-1:
        right.append(main[j])
        j+=1
    print(abs(sum(left)-sum(right)))
a=int(input())
b=list(map(int,input().split()))

count=0

i=1
while i < len(b):
    temp=b[:i]
    if b[i]>max(temp) or b[i]<min(temp):
        count+=1
    i+=1
print(count)
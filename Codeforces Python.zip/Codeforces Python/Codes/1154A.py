a=list(map(int,input().split()))
a.sort()
print(a[3]-a[0],a[3]-a[1],a[3]-a[2])


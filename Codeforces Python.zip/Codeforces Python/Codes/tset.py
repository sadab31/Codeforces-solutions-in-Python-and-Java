class A:
    def __init__(self):
        self.emnei("sadamada")
    def emnei(self,a):
        print(a)

obj=A()
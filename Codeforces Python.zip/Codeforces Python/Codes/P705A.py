a=int(input())
m="I love"
n="I hate"
s=""
i=1
while i<=a:
    if i%2==0:
        if i==a:
            s=s+m+" it "
            break
        s=s+m+" that "
    else:
        if i==a:
            s=s+n+" it "
            break
        s=s+n+" that "
    i+=1
print(s)
n=int(input())
a=list(map(int,input().split()))

list2=a.copy()
list2.sort()
ones=list2.count(1)
twos=list2.count(2)
threes=list2.count(3)
teams=min(ones,twos,threes)
print(teams)
if teams==1 and len(a)==3:
    print(1,2,3)
else:

    count = 0
    index=""
    while True:
        if count==teams:
            break
        i = 0
        team = [1, 2, 3]
        index = ""
        while i < n:

            if a[i] != False and a[i] in team:

                index += str(i + 1) + " "
                team.remove(a[i])
                a[i] = False

            i += 1

        if len(index) >= 6:
            print(index)
        count+=1




a,b=map(int,input().split())
count=a

while True:
    if a<b:
        break
    count+=a//b
    a=a//b + a%b

print(count)
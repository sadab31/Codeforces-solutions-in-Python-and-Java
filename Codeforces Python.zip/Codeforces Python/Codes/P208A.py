n=input()
n=n.split("WUB")
word=""
for i in n:
    if i != "":
        word=word+i+" "
print(word)
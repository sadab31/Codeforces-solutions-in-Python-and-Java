a=int(input())
count=0
for i in range(a):
    b=int(input())
    if(b==1):
        count=count+1

if count!=0:
    print("HARD")
else:
    print("EASY")

a,b,x,y,n=map(int,input().split())
difx=a-x
dify=a-y
0

if a-n>x:
    s=(a-n)*b
else:
    s=a*b
if b-n>y:
    t=(b-n)*a
else:
    t=a*b



min=min(s,t)
print(min)

while a>=x and b>=y:
    k=a*b
    if k < min:
        min=k
        break
    a-=1
    b-=1
if min<k:
    print(min)
else:
    print(k)

t=int(input())
for i in range(t):
    n, k = map(int, input().split())
    a = list(map(int, input().split()))
    b = list(map(int, input().split()))

    a.sort()
    b.sort()
    b.reverse()

    i = 0
    kcount=0
    while i < len(a):
        if kcount<k:
            if a[i] < b[i]:
                a[i] = b[i]
                kcount+=1
        i += 1

    print(sum(a))
t=int(input())
for i in range(t):
    n=int(input())
    a = list(map(int, input().split()))
    b = list(map(int, input().split()))
    candyLeast = min(a)
    orangeLeast = min(b)

    moves = 0
    i = 0
    while i < n:
        candy = a[i] - candyLeast
        orange = b[i] - orangeLeast
        moves += abs(candy - orange) + min(candy, orange)
        i += 1
    print(moves)
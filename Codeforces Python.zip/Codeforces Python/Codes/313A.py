n=input()
if n[0]!="-":
    print(int(n))
else:
    last=n[-1]
    secLast=n[-2]
    if last>secLast:
        n=n[:-1]
        print(int(n))
    else:
        n=n[:-2]+n[-1]
        print(int(n))
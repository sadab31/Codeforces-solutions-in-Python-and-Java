t=int(input())
for i in range(t):
    s = input()
    f=s[0]
    l=s[-1]
    i=1
    new=""
    while i<len(s)-2:
        new+=s[i]
        i+=2
    new=f+new+l
    print(new)
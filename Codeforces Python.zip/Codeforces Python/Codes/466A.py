n,m,a,b=map(int,input().split())
s1=n*a
s2=0
s3=0
s4=0

if n%m==0:
    s2=(n//m)*b
else:
    s3=(n//m)*b
    s3+=(n%m)*a
    s4=((n//m)+1)*b
l=[]
l.append(s1)
if s2!=0:
    l.append(s2)
if s3!=0:
    l.append(s3)
if s4!=0:
    l.append(s4)
print(min(l))
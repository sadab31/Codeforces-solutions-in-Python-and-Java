n=int(input())
a=list(map(int,input().split()))
a[0]=0
b=list(map(int,input().split()))
b[0]=0
count=0

for i in range(1,n+1):
    if i not in a and i not in b:
        count+=1

        break
if count==0:
    print("I become the guy.")
else:
    print("Oh, my keyboard!")

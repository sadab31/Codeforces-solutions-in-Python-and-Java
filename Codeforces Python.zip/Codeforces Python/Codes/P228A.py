list=list(map(int,input().split()))
count=0
temp=0
for i in range(len(list)-1,-1,-1):
    if list[i]==temp:
        continue

    for j in range(i-1,-1,-1):
        if list[i]==list[j]:
            count+=1
    temp=list[i]
print(count)
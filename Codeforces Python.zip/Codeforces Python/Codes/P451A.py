a = list(map(int, input().split()))
c = a[1]
b = a[0]
count1 = 1
count2 = 0

i = 2
while True:
    if (b - 1) * (c - 1) > 0:
        if i % 2 != 0:
            count1 += 1
        else:
            count2 += 1
        b = b - 1
        c = c - 1
    else:
        break

    i += 1

if count1 > count2:
    print("Akshat")
else:
    print("Malvika")

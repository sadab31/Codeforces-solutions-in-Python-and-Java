a,b=input().split()
t=60*4-int(b)
i=1
count=0
total=0
while i <=int(a):
    total+=5*i
    if total>t:
        break
    else:
        count+=1
    i+=1
print(count)

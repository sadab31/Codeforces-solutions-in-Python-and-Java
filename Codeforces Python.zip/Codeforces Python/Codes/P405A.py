

n=int(input())
list = list(map(int, input().split()))

list.sort()
for i in list:
    print(i,end=" ")

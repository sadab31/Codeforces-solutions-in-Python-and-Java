n=int(input())
for i in range(n):
    length=int(input())
    a=list(map(int,input().split()))
    j=0
    min=max(a)
    a.sort()
    while j<length-1:
        if a[j+1]-a[j]<min:
            min=a[j+1]-a[j]

        j+=1
    print(min)
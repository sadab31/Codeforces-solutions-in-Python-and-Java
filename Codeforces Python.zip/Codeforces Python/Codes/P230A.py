a=list(map(int,input().split()))
s=a[0]
count=0
l=[]
for i in range (a[1]):
    b=list(map(int,input().split()))
    l.append(b)
l.sort()

for i in l:
    if s>i[0]:
        s=s+i[1]
    else:
        count+=1
        break
if count!=0:
    print("NO")
else:
    print("YES")
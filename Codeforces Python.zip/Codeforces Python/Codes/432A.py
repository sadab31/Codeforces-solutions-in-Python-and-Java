n,k=map(int,input().split())
p=list(map(int,input().split()))
new=[]
for i in p:
    if i<5:
        new.append(i)
new.sort()

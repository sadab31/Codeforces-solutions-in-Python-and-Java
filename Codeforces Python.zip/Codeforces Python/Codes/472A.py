def prime(a):

    if a == 1:
        return False
    else:

        count = 0

        i = 2
        while i < ((a//2)+1):
            if a % i == 0:
                count += 1
                break
            else:
                i += 1
        if count == 0:
            return True
        else:
            return False


num=int(input())
if num%2==0 and prime(num//2)==False and prime(num//2)==False:
    print(num//2,num//2)
else:
    i=4
    a=1
    while a>0:
        a=num-i
        if prime(a)==False and prime(i)==False:

            print(a,i)
            break

        i+=1
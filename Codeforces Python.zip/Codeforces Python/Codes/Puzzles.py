m,n=input().split()
m=int(m)
n=int(n)

list = list(map(int, input().split()))
list.sort()


diffx=list[m-1]-list[0]
low=0
high=m-1
while high<len(list):
    diff=list[high]-list[low]
    if diff < diffx:
        diffx=diff
    low+=1
    high+=1
print(diffx)

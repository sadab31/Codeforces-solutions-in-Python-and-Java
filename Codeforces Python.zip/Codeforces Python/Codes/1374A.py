t=int(input())
for i in range(t):
    x, y, n = map(int, input().split())
    p=(n-y)//x
    print(p*x+y)
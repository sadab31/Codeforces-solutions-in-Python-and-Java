t=int(input())
for j in range(t):
    a, b = map(int, input().split())
    diff = abs(a - b)

    if diff <= 10 and diff!=0:
        print(1)
    elif diff<=10 and diff==0:
        print(0)
    else:
        count = 0
        i = 10
        while i >= 1:
            count = count + diff // i
            diff = diff % i
            if diff == 0:
                break

            i -= 1
        print(count)

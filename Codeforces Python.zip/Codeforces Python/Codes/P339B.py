a=list(map(int,input().split()))
b=list(map(int,input().split()))
i=1
count=0
n=a[0]


for k in b:
    temp=0
    if i<k:
        count+=k-i
        i=k
    elif i>k:
        temp=n-i+1
        temp=temp+(k-1)
        count+=temp
        i=k
    else:
        i=k

print(count)


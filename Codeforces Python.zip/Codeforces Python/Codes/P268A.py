n=int(input())
list1=[]
list2=[]
count=0

for i in range(n):
    s=list(map(int,input().split()))
    list1.append(s[0])
    list2.append(s[1])
for i in list1:
    if i in list2:
        count+=list2.count(i)
print(count)
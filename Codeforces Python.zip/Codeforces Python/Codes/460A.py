n,m=map(int,input().split())

i=1
t=1
while True:
    t=i*m
    if t<=n:
        n+=1
    else:
        break

    i+=1
print(n)
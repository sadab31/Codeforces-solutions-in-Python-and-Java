s=input()
p=input()
m=input()
s=s+p
s=sorted(s)
m=sorted(m)
if s==m:
    print("YES")
else:
    print("NO")

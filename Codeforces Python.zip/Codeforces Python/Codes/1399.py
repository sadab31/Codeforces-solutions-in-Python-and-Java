t=int(input())
for i in range(t):
    n = input()
    a = list(map(int, input().split()))
    a.sort()
    i = 0
    while i < len(a) - 1:

        if a[i + 1] - a[i] == 1 or a[i] == a[i + 1]:
            a.remove(a[i])
            i -= 1

        i += 1
    if len(a)!=1:
        print("NO")
    else:
        print("YES")

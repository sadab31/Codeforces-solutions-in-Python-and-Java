t=int(input())
for i in range(t):
    n = int(input())
    a = list(map(int, input().split()))


    def indexGen(a):
        temp = list(range(a))
        # temp2=[]
        # for i in a:
        #     temp.append(i%2)
        return mainGen(temp)


    def mainGen(a):
        temp = []
        for i in a:
            temp.append(i % 2)
        return temp


    list1 = mainGen(a)
    list2 = indexGen(n)
    if list1 == list2:
        print(0)
    else:
        list1Sorted = list1.copy()
        list2Sorted = list2.copy()
        list2Sorted.sort()
        list1Sorted.sort()
        if list1Sorted != list2Sorted:
            print(-1)
        else:

            count = 0
            i = 0
            while i < n:
                if list1[i] != list2[i]:
                    count += 1
                i += 1
            print(count // 2)


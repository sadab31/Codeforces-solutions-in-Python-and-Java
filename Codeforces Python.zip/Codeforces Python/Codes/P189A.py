lis=list(map(int,input().split()))

lis.sort()

a=lis[0]
b=lis[1]
c=lis[2]
n=lis[3]

diff=n
count=0
temp=a
i=a
while True:
    if i>n:
        break


    if diff== b or diff ==c or diff==a:

        if a+b==diff or a+c==diff or b+c==diff :
            count+=2
            break
        else:

            count+=1
            break
    else:
        count+=1

    diff = n - i
    i+=temp
if a==1 and n!=1:
    print(count+1)
else:
    print(count)
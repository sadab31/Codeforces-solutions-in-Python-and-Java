n=int(input())
tax=list(map(int,input().split()))
tax.sort()
sum=0
highest=tax[-1]
for i in tax:
    sum+=highest-i
print(sum)
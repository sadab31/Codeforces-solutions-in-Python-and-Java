n=int(input())

dic={}
for i in range(n):
    m=input()
    if m not in dic:
        print("OK")
        dic[m]=0
    else:
        dic[m]+=1
        new=m+str(dic[m])
        print(new)

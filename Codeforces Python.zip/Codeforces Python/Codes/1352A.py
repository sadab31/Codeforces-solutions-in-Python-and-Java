t = int(input())
for i in range(t):
    a = input()
    l = []
    s=""
    if len(a) == 5:
        l.append(a[0] + "0000")
        l.append(a[1] + "000")
        l.append(a[2] + "00")
        l.append(a[3]+"0")
        l.append(a[4])
    if len(a) == 4:
        l.append(a[0] + "000")
        l.append(a[1] + "00")
        l.append(a[2] + "0")
        l.append(a[3])
    elif len(a) == 3:
        l.append(a[0] + "00")
        l.append(a[1] + "0")
        l.append(a[2])
    elif len(a) == 2:
        l.append(a[0] + "0")
        l.append(a[1])

    elif len(a) == 1:

        l.append(a[0])
    count=0
    l.reverse()
    for i in l:
        if int(i)!=0:
           count+=1
           s=s+i+" "
    print(count)
    print(s)
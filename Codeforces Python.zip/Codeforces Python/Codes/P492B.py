a=list(map(int,input().split()))
b=list(map(int,input().split()))
b.sort()

first=float(b[0])
last=float(a[1]-b[a[0]-1])


i=0
high=0
while i<=len(b)-2:

    if abs(b[i]-b[i+1])>high:
        high=abs(b[i]-b[i+1])



    i+=1
highst=float(high/2)
ans=0
if highst>first and highst>last:
    ans=highst
elif first>highst and first>last:
    ans=first
elif last>first and last>highst:
    ans=last


print(format(ans,"10f"))

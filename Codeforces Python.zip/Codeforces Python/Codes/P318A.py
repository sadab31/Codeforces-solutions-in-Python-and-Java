a,b=input().split()
a=int(a)
b=int(b)
if a%2==0:
    if b<=(a//2):
        print(b+(b-1))
    else:
        print(b-(a%b))
else:
    if b <= ((a // 2)+1):
        print(b + (b - 1))
    else:
        print((b - (a % b))-1)
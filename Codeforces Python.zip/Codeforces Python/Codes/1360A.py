t=int(input())
for i in range(t):
    a = list(map(int, input().split()))
    a.sort()
    if a[0] * 2 >= a[1]:
        print(a[0] * 2 * 2 * a[0])
    else:
        print(a[1] * a[1])



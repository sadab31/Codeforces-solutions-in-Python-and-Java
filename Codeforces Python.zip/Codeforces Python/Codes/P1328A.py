t=int(input())
for i in range(t):
    list1=list(map(int,input().split()))
    a=list1[0]
    b=list1[1]
    temp=a//b

    temp+=1
    if a%b==0:
        print(0)
    else:

        print((b*temp)-a)
n=int(input())
bar=list(map(int,input().split()))
d,m=map(int,input().split())
ways=0
i=0
while i<len(bar):
    temp=bar[i]
    j=i
    sum=0
    while j<=j+m-1 and j+m-1<len(bar):
        sum+=bar[j]

        j+=1
    print("sum", sum)
    if sum==d:
        ways+=1

    i+=1
print(ways)
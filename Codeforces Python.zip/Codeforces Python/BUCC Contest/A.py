n=int(input())
if n%2==0:
    print("All hail R@D!X2.0 - BUCC Week")
else:
    print('''"Hola BUCCians!!"''')
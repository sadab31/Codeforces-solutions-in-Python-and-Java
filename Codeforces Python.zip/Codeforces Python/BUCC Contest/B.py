s=input()
s=s[4:-1]
l=list(s)

i=0
k=""

while i < len(l):
    count=1
    temp=l[i]
    j=i+1
    while j< len(l):
        if l[j]==temp:
            count+=1
        else:
            break

        j+=1
    if count==1:
        k+=temp
    else:
        i+=(count-1)
        k=k+str(count)+temp


    i+=1
print(k)
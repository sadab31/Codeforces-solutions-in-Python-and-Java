n=int(input())
answer=""
if n<10:
    answer=int("1"+str(n))
else:
    if n%2==0:
        answer=int("2"+str(n//2))
    else:
        half=n//2
        i=2
        j=half

        while j>0:
            if i*j==n:
                answer=int(str(i)+str(j))
                break
            else:
                if i*j>n:
                    i=1
                    j-=1


            i+=1


if answer==int(str(n)+"1"):
    print(-1)
else:
    print(answer)
def g(num):
  factor = [1]
  for i in range(2,num+1):
     if num%i==0:
         factor.append(i)
  return sum(factor)

t=int(input())
for i in range(t):
    x, y = map(int, input().split())

    i = x
    summation = 0
    while i <= y:
        summation += g(i)
        i += 1
    print(summation)
